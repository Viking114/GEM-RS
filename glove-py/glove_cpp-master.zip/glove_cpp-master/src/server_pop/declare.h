#ifndef DECLARE_h
#define DECLARE_h

#include <functional>
#include <memory>
#include <map>
#include <vector>
#include <netinet/in.h>
#include <iostream>

typedef std::function<void()>  FUN;


#endif
