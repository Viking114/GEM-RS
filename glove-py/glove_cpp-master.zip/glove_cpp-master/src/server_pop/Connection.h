#ifndef PROJECT_CONNECTION_H
#define PROJECT_CONNECTION_H

#include "Buffer.h"


class Connection {
public:

    Buffer _input;
    Buffer _output;
};


#endif //PROJECT_CONNECTION_H
