#include "trace.h"
int Info::lv=1;
