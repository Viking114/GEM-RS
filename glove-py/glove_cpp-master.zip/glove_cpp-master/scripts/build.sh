#!/usr/bin/env bash


#只是编译
cd ../build
rm -rf *

cmake ..
make



